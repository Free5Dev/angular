import {Component} from "@angular/core";

@Component({
    selector: 'my-app',
    template: '<h1>Salut à tous</h1>'
})
export class appComponent {
    
}