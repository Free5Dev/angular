import {Component} from "@angular/core";

@Component({
    selector: 'item',
    templateUrl: 'app/item.html'
})
export class Item {
}