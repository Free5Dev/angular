import {bootstrap} from "@angular/platform-browser-dynamic";
import {appComponent} from "./app.component";

bootstrap(appComponent, []);