export class Config {
    public static get APP_TITLE(): string { return 'Application livreur pour le client'; }
    public static get APP_VERSION(): string { return '1.0'; }
}