"use strict";
var Item = (function () {
    function Item(data) {
        this.reference = data.reference;
        this.name = data.name;
        this.state = data.state;
    }
    return Item;
}());
exports.Item = Item;
//# sourceMappingURL=item.js.map