import {Component} from "@angular/core";

@Component({
    selector: 'my-app',
    template: `
    <h1>
        Salut à tous
    </h1>
    <p>Un paragraphe</p>
    `
})
export class appComponent {
    
}