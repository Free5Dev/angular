'use strict';

var app = angular.module('collectify', []);