'use strict';

app
    .controller('itemIndex', function ($scope) {

    })
    .controller('itemList', function ($scope) {

    })
    .controller('itemCreate', function ($scope) {

    })
    .controller('itemRemove', function ($scope) {

    })
;