'use strict';

var items = [
    {'name': 'Django Unchained', 'category_id': 1},
    {'name': 'Forrest Gump', 'category_id': 1}
];

app
    .controller('itemIndex', function ($scope) {

    })
    .controller('itemList', function ($scope) {

    })
    .controller('itemCreate', function ($scope) {

    })
    .controller('itemRemove', function ($scope) {

    })
;