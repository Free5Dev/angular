'use strict';

app.directive('decorateItem', function () {
    return {
        templateUrl: 'views/item/directive/decorator.html',
        restrict: 'E'
    }
})