'use strict';

app
    .controller('categoryIndex', function ($scope) {

    })
    .controller('categoryList', function ($scope) {

    })
    .controller('categoryCreate', function ($scope) {

    })
    .controller('categoryRemove', function ($scope) {

    })
;