'use strict';

var categories = [
    {'id': 1, 'name': 'films'},
    {'id': 2, 'name': 'musiques'}
];

app
    .controller('categoryIndex', function ($scope) {

    })
    .controller('categoryList', function ($scope) {

    })
    .controller('categoryCreate', function ($scope) {

    })
    .controller('categoryRemove', function ($scope) {

    })
;